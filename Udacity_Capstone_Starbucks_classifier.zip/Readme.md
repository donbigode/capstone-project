Udacity Data Scientist Nanodegree Capstone Project
Starbucks-Capstone-Project
This repository has all the code and report for my Udacity Data Scientist Nanodegree Capstone project.

Problem Statement:  

The problem is to determine the best offer to be submitted to a user based on their response to previously received offers. 

Each customer has different offers being received; thus, the datasets could compose training and testing data masses to enable a model to be created to predict customer events based on a series of variables. 

Installations
This project was written in Python, using Jupyter Notebook on Anaconda. The relevant Python packages for this project are as follows:

pandas
numpy
math
json
matplotlib
seaborn
sklearn.model_selection (train_test_split module and cross_validate)
sklearn.preprocessing (StandardScaler)
sklearn.decomposition (PCA)
sklearn.naive_bayes (MultinomialNB)
File Descriptions
This repo contains 4 files.

Starbucks_Capstone_notebook.ipynb : the code notebook .
Capstone-Project-Report.pdf : my project report .
Data :
Profile.json
Portfolio.json
transcript.json 
Licensing, Authors, Acknowledgements .
Data for coding project was provided by Udacity.